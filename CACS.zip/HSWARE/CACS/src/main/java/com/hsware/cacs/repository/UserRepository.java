package com.hsware.cacs.repository;

import com.hsware.cacs.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Integer> {

    List<User> findByDeletedAtIsNull();

    Optional<User> findByIdAndDeletedAtIsNull(Integer id);

    Optional<User> findByAccessCard_Id(Integer accessCardId);

    Optional<User> findByEmailAndDeletedAtIsNull(String email);

    /** Users responsible for this zone (zone_responsibility join) */
    java.util.List<User> findByResponsibleZones_IdAndDeletedAtIsNull(Integer zoneId);
}
