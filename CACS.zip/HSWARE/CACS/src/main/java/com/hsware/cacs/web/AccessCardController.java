package com.hsware.cacs.web;

import com.hsware.cacs.dto.AccessCardDTO;
import com.hsware.cacs.dto.AccessCardCreateDTO;
import com.hsware.cacs.dto.AccessCardUpdateDTO;
import com.hsware.cacs.service.AccessCardService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/access-cards")
@RequiredArgsConstructor
@CrossOrigin(origins = "*", maxAge = 3600)
public class AccessCardController {

    private final AccessCardService accessCardService;

    @GetMapping
    public List<AccessCardDTO> list() {
        return accessCardService.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<AccessCardDTO> get(@PathVariable Integer id) {
        return accessCardService.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<AccessCardDTO> create(@RequestBody AccessCardCreateDTO body) {
        AccessCardDTO created = accessCardService.create(body);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @PutMapping("/{id}")
    public ResponseEntity<AccessCardDTO> update(@PathVariable Integer id, @RequestBody AccessCardUpdateDTO body) {
        return accessCardService.update(id, body)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Integer id) {
        return accessCardService.delete(id)
                ? ResponseEntity.noContent().build()
                : ResponseEntity.notFound().build();
    }
}
